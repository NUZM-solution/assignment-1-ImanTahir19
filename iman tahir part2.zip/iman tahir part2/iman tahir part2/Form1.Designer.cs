﻿namespace iman_tahir_part2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            groupBox1 = new GroupBox();
            button1 = new Button();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtCourseTitle = new TextBox();
            txtStatus = new TextBox();
            txtGrade = new TextBox();
            txtCourseCode = new TextBox();
            txtObtainedMarks = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(15, 80);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1235, 282);
            dataGridView1.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ButtonHighlight;
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtCourseTitle);
            groupBox1.Controls.Add(txtStatus);
            groupBox1.Controls.Add(txtGrade);
            groupBox1.Controls.Add(txtCourseCode);
            groupBox1.Controls.Add(txtObtainedMarks);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1238, 55);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            // 
            // button1
            // 
            button1.Location = new Point(1102, 13);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 11;
            button1.Text = "submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(927, 18);
            label5.Name = "label5";
            label5.Size = new Size(60, 25);
            label5.TabIndex = 10;
            label5.Text = "Status";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(769, 18);
            label4.Name = "label4";
            label4.Size = new Size(59, 25);
            label4.TabIndex = 9;
            label4.Text = "Grade";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(521, 18);
            label3.Name = "label3";
            label3.Size = new Size(139, 25);
            label3.TabIndex = 8;
            label3.Text = "Obtained Marks";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(246, 18);
            label2.Name = "label2";
            label2.Size = new Size(104, 25);
            label2.TabIndex = 7;
            label2.Text = "Course Title";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(0, 15);
            label1.Name = "label1";
            label1.Size = new Size(114, 25);
            label1.TabIndex = 6;
            label1.Text = "Course Code";
            // 
            // txtCourseTitle
            // 
            txtCourseTitle.Location = new Point(356, 12);
            txtCourseTitle.Name = "txtCourseTitle";
            txtCourseTitle.Size = new Size(159, 31);
            txtCourseTitle.TabIndex = 4;
            // 
            // txtStatus
            // 
            txtStatus.Location = new Point(993, 15);
            txtStatus.Name = "txtStatus";
            txtStatus.Size = new Size(82, 31);
            txtStatus.TabIndex = 3;
            // 
            // txtGrade
            // 
            txtGrade.Location = new Point(834, 15);
            txtGrade.Name = "txtGrade";
            txtGrade.Size = new Size(77, 31);
            txtGrade.TabIndex = 2;
            // 
            // txtCourseCode
            // 
            txtCourseCode.Location = new Point(120, 12);
            txtCourseCode.Name = "txtCourseCode";
            txtCourseCode.Size = new Size(116, 31);
            txtCourseCode.TabIndex = 1;
            // 
            // txtObtainedMarks
            // 
            txtObtainedMarks.Location = new Point(666, 12);
            txtObtainedMarks.Name = "txtObtainedMarks";
            txtObtainedMarks.Size = new Size(83, 31);
            txtObtainedMarks.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1262, 450);
            Controls.Add(groupBox1);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private GroupBox groupBox1;
        private TextBox txtCourseTitle;
        private TextBox txtStatus;
        private TextBox txtGrade;
        private TextBox txtCourseCode;
        private TextBox txtObtainedMarks;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button button1;
    }
}
