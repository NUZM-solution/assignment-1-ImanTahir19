using System.Data;

namespace iman_tahir_part2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SetupDataGrid();
        }
       
        DataTable dt = new DataTable();

      
        private void SetupDataGrid()
        {
           
            dt.Columns.Add("Course Code", typeof(string));
            dt.Columns.Add("Course Title", typeof(string));
            dt.Columns.Add("Obtained Marks", typeof(int));
            dt.Columns.Add("Grade", typeof(string));
            dt.Columns.Add("Status", typeof(string));

           
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
         
            DataRow row = dt.NewRow();

            
            row["Course Code"] = txtCourseCode.Text;      
            row["Course Title"] = txtCourseTitle.Text;     
            row["Obtained Marks"] = Convert.ToInt32(txtObtainedMarks.Text); 
            row["Grade"] = txtGrade.Text;                  
            row["Status"] = txtStatus.Text;                

            
            dt.Rows.Add(row);
        }
    }
}
